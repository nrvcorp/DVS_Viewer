/*****************************************************************************
 * File        : DELTA_Processing.hpp
 * Module      : DELTA Processing API
 * Description : Declares output map and processing parameter functions for
 *               the DELTA SDK.
 *****************************************************************************/

#ifndef DELTA_PROCESSING_HPP
#define DELTA_PROCESSING_HPP

#include "DELTA_Status.hpp"
#include "DELTA_Types.hpp"

namespace delta {

/*****************************************************************************
 * Prototype    : Status getInputSourceType(InputSource* handle,
 *                                          InputSourceType* type);
 * Description  : Gets whether an input source was opened from a file or device.
 * Parameters   : [handle] Input source handle returned by openDevice() or openFile().
 *                [type]   Receives input source type.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status getInputSourceType(InputSource* handle,
                                      InputSourceType* type);

// ============================================================================
// Frame Generation
//
// Generated frames can be separated by one of three modes:
// 1. Time based: one frame is generated every framePeriodMs.
// 2. Event count based: one frame is generated every eventsPerFrame events.
// 3. Frame-end based: one frame is generated every frameEndCount frame-end packets.
// ============================================================================
enum class FrameMode
{
    FrameEndBased,
    TimeBased,
    EventCountBased
};

struct FrameGeneration
{
    FrameMode mode;
    std::int32_t parameter;
};

/*****************************************************************************
 * Prototype    : FrameGeneration frameEndBased(std::int32_t frameEndCount);
 * Description  : Creates a frame generation setting for frame-end based output.
 * Parameters   : [frameEndCount] Number of frame-end packets per generated frame.
 * Return Value : Frame generation setting for frame-end based processing.
 *****************************************************************************/
DELTA_SDK FrameGeneration frameEndBased(std::int32_t frameEndCount);

/*****************************************************************************
 * Prototype    : FrameGeneration timeBased(std::int32_t framePeriodMs);
 * Description  : Creates a frame generation setting for time based output.
 * Parameters   : [framePeriodMs] Frame generation period in milliseconds.
 * Return Value : Frame generation setting for time based processing.
 *****************************************************************************/
DELTA_SDK FrameGeneration timeBased(std::int32_t framePeriodMs);

/*****************************************************************************
 * Prototype    : FrameGeneration eventCountBased(std::int32_t eventsPerFrame);
 * Description  : Creates a frame generation setting for event-count based output.
 * Parameters   : [eventsPerFrame] Number of events per generated frame.
 * Return Value : Frame generation setting for event-count based processing.
 *****************************************************************************/
DELTA_SDK FrameGeneration eventCountBased(std::int32_t eventsPerFrame);

/*****************************************************************************
 * Prototype    : Status setFrameGeneration(InputSource* handle,
 *                                          FrameGeneration generation);
 * Description  : Sets how raw events are separated into generated frames.
 *                Can be called before or after startStream()/startPlayback().
 *                Changes take effect at the next frame boundary.
 *
 *                Default (applied automatically on open):
 *                  FrameEndBased, frameEndCount = 16 [Recommended Delta-01]
 *                  FrameEndBased, frameEndCount = 33 [Recommended Delta-10]
 *
 *                Note: startFrameSaving() accepts its own FrameGeneration
 *                and overrides this setting for the duration of the save.
 * Parameters   : [handle]     Input source handle returned by openDevice() or openFile().
 *                [generation] Frame generation mode and parameter.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status setFrameGeneration(InputSource* handle,
                                      FrameGeneration generation);

/*****************************************************************************
 * Prototype    : Status getFrameGeneration(InputSource* handle,
 *                                          FrameGeneration* generation);
 * Description  : Gets the current frame generation mode and parameter.
 * Parameters   : [handle]     Input source handle returned by openDevice() or openFile().
 *                [generation] Receives frame generation mode and parameter.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status getFrameGeneration(InputSource* handle,
                                      FrameGeneration* generation);

// ============================================================================
// Output Type
//
// The SDK can generate multiple processed outputs from the same input source.
// OutputType selects which outputs are generated and stored internally.
// 1. ColorFrame: rendered image frame for display or image saving.
// 2. PolarityFrame: per-pixel polarity map for one generated frame.
// 3. TimestampFrame: per-pixel latest ON/OFF timestamp maps.
// 4. ClassicEvents: x, y, polarity, timestamp event list.
// 5. CompactEvents: compact nrv dvs event list with one timestamp per frame.
// ============================================================================
enum class OutputType : std::uint32_t
{
    ColorFrame     = 1 << 0,
    PolarityFrame  = 1 << 1,
    TimestampFrame = 1 << 2,
    ClassicEvents  = 1 << 3,
    CompactEvents  = 1 << 4,
    All            = (1 << 0) | (1 << 1) | (1 << 2) | (1 << 3) | (1 << 4)
};

/*****************************************************************************
 * Prototype    : Status setOutputType(InputSource* handle,
 *                                     OutputType outputType);
 * Description  : Sets which processing outputs are generated internally.
 *                Multiple outputs can be combined with bitwise OR.
 *
 *                Default:
 *                  OutputType::All
 *
 *                Example:
 *                  OutputType::ColorFrame
 *                  OutputType::ColorFrame | OutputType::PolarityFrame
 * Parameters   : [handle]     Input source handle returned by openDevice() or openFile().
 *                [outputType] Output type flags to enable.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status setOutputType(InputSource* handle,
                                OutputType outputType);

/*****************************************************************************
 * Prototype    : Status getOutputType(InputSource* handle,
 *                                     OutputType* outputType);
 * Description  : Gets the currently enabled output type flags.
 * Parameters   : [handle]     Input source handle returned by openDevice() or openFile().
 *                [outputType] Receives currently enabled output type flags.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status getOutputType(InputSource* handle,
                                OutputType* outputType);

/*****************************************************************************
 * Prototype    : Status setColorFormat(InputSource* handle,
 *                                      ColorFormat format);
 * Description  : Sets the output format used by getColorFrame() only.
 *
 *                Default:
 *                  ColorFormat::Gray
 *
 *                When ColorFormat::Gray is selected, the SDK applies the
 *                default grayscale event colors:
 *                  ON event  = white
 *                  OFF event = black
 *                  no event  = gray
 *
 *                When ColorFormat::RGB is selected, the SDK applies the
 *                default RGB event colors:
 *                  ON event  = red
 *                  OFF event = blue
 *                  no event  = white
 *
 *                Use setColor() after this function to override the default
 *                colors for ON, OFF, and no-event pixels.
 * Parameters   : [handle] Input source handle returned by openDevice() or openFile().
 *                [format] Color frame output format.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status setColorFormat(InputSource* handle,
                                  ColorFormat format);

/*****************************************************************************
 * Prototype    : Status getColorFormat(InputSource* handle,
 *                                      ColorFormat* format);
 * Description  : Gets the current output format used by getColorFrame() only.
 * Parameters   : [handle] Input source handle returned by openDevice() or openFile().
 *                [format] Receives current color frame output format.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status getColorFormat(InputSource* handle,
                                  ColorFormat* format);

/*****************************************************************************
 * Prototype    : Status setColor(InputSource* handle,
 *                                const EventColor* color);
 * Description  : Sets the ON, OFF, and no-event pixel colors for getColorFrame() only.
 *
 *                In ColorFormat::RGB mode, each Color value is interpreted as
 *                red, green, blue.
 *
 *                In ColorFormat::Gray mode, each Color value is converted to
 *                one grayscale intensity before being applied.
 *
 *                If this function is not called, the SDK uses the default
 *                colors selected by setColorFormat().
 * Parameters   : [handle] Input source handle returned by openDevice() or openFile().
 *                [color]  ON, OFF, and no-event colors.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status setColor(InputSource* handle,
                            const EventColor* color);

/*****************************************************************************
 * Prototype    : Status getColor(InputSource* handle,
 *                                EventColor* color);
 * Description  : Gets the ON, OFF, and no-event pixel colors for getColorFrame() only.
 * Parameters   : [handle] Input source handle returned by openDevice() or openFile().
 *                [color]  Receives current event colors.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status getColor(InputSource* handle,
                            EventColor* color);

/*****************************************************************************
 * Prototype    : Status getColorFrame(InputSource* handle,
 *                                     ColorFrame* output,
 *                                     std::int32_t cameraIndex);
 * Description  : Gets one rendered color frame generated from the current
 *                frame generation mode set by setFrameGeneration().
 *                One call returns one generated frame for the selected camera.
 *
 *                The frame is built from per-pixel event activity. In the
 *                default grayscale format, each output byte is one pixel
 *                intensity value. In RGB format, each pixel uses three bytes
 *                in red, green, blue order.
 *
 *                The caller owns the output memory. Set output->startAddress
 *                to the first byte of the output buffer and set
 *                output->bufferSize to the allocated byte count.
 *                Use getColorFrameBufferSize(handle) to get the required
 *                bufferSize value for the current ColorFormat.
 *
 *                DVS resolution example (960 x 720, grayscale):
 *                  required bufferSize = 960 * 720 = 691200 bytes
 *                  std::vector<std::uint8_t> buffer(691200);
 *                  output.startAddress = buffer.data();
 *                  output.bufferSize   = 691200;
 *
 *                DVS resolution example (960 x 720, RGB):
 *                  required bufferSize = 960 * 720 * 3 = 2073600 bytes
 * Parameters   : [handle]      Input source handle returned by openDevice() or openFile().
 *                [output]      Receives one rendered image frame.
 *                [cameraIndex] Camera index. Use 0 for single camera devices.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status getColorFrame(InputSource* handle,
                                 ColorFrame* output,
                                 std::int32_t cameraIndex);

/*****************************************************************************
 * Prototype    : std::uint32_t getColorFrameBufferSize(InputSource* handle);
 * Description  : Gets the required ColorFrame::bufferSize value in bytes for
 *                the current sensor resolution and ColorFormat.
 *
 *                Call this after openDevice()/openFile() and applySensorSetting()
 *                before allocating ColorFrame::startAddress.
 *
 *                DVS resolution example (960 x 720, grayscale):
 *                  getColorFrameBufferSize(handle) returns 691200 bytes.
 *
 *                DVS resolution example (960 x 720, RGB):
 *                  getColorFrameBufferSize(handle) returns 2073600 bytes.
 * Parameters   : [handle] Input source handle returned by openDevice() or openFile().
 * Return Value : Required byte count, or 0 when the handle is invalid.
 *****************************************************************************/
DELTA_SDK std::uint32_t getColorFrameBufferSize(InputSource* handle);

/*****************************************************************************
 * Prototype    : Status getPolarityFrame(InputSource* handle,
 *                                        PolarityFrame* output,
 *                                        std::int32_t cameraIndex);
 * Description  : Gets one per-pixel polarity frame generated from the current
 *                frame generation mode set by setFrameGeneration().
 *                One call returns one generated frame for the selected camera.
 *
 *                Unlike getClassicEvents(), this output has one value for every pixel.
 *                Each int8_t value represents the latest polarity state stored
 *                for that pixel in the generated frame:
 *                  0  = ON event
 *                  1  = OFF event
 *                 -1  = no event
 *
 *                The caller owns the output memory. Set output->startAddress
 *                to the first element of the output buffer and set
 *                output->bufferSize to the allocated byte count.
 *                Use getPolarityFrameBufferSize(handle) to get the required
 *                bufferSize value.
 *
 *                DVS resolution example (960 x 720):
 *                  required bufferSize = 960 * 720 = 691200 bytes
 *                  std::vector<std::int8_t> buffer(691200);
 *                  output.startAddress = buffer.data();
 *                  output.bufferSize   = 691200;
 * Parameters   : [handle]      Input source handle returned by openDevice() or openFile().
 *                [output]      Receives polarity frame data for one camera.
 *                [cameraIndex] Camera index. Use 0 for single camera devices.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status getPolarityFrame(InputSource* handle,
                                    PolarityFrame* output,
                                    std::int32_t cameraIndex);

/*****************************************************************************
 * Prototype    : std::uint32_t getPolarityFrameBufferSize(InputSource* handle);
 * Description  : Gets the required PolarityFrame::bufferSize value in bytes
 *                for the current sensor resolution.
 *
 *                Call this after openDevice()/openFile() and applySensorSetting()
 *                before allocating PolarityFrame::startAddress.
 *
 *                DVS resolution example (960 x 720):
 *                  getPolarityFrameBufferSize(handle) returns 691200 bytes.
 * Parameters   : [handle] Input source handle returned by openDevice() or openFile().
 * Return Value : Required byte count, or 0 when the handle is invalid.
 *****************************************************************************/
DELTA_SDK std::uint32_t getPolarityFrameBufferSize(InputSource* handle);

/*****************************************************************************
 * Prototype    : Status getTimestampFrame(InputSource* handle,
 *                                         TimestampFrame* output,
 *                                         std::int32_t cameraIndex);
 * Description  : Gets one per-pixel timestamp frame generated from the current
 *                frame generation mode set by setFrameGeneration().
 *                One call returns one generated frame for the selected camera.
 *
 *                This output has two timestamp buffers: one for the latest ON
 *                event timestamp per pixel and one for the latest OFF event
 *                timestamp per pixel. Timestamp values are in microseconds.
 *                A value of 0 means no timestamp is stored for that pixel.
 *
 *                The caller owns both output buffers. Set output->onEvent and
 *                output->offEvent to the first uint32_t element of each buffer.
 *                output->bufferSize is the allocated byte count for each one
 *                of those two buffers, not the combined total.
 *                Use getTimestampFrameBufferSize(handle) to get the required
 *                bufferSize value for each timestamp buffer.
 *
 *                DVS resolution example (960 x 720):
 *                  pixels = 960 * 720 = 691200
 *                  required bufferSize per array =
 *                    691200 * sizeof(std::uint32_t) = 2764800 bytes
 *                  std::vector<std::uint32_t> on(691200);
 *                  std::vector<std::uint32_t> off(691200);
 *                  output.onEvent    = on.data();
 *                  output.offEvent   = off.data();
 *                  output.bufferSize = 2764800;
 * Parameters   : [handle]      Input source handle returned by openDevice() or openFile().
 *                [output]      Receives timestamp frame data for one camera.
 *                [cameraIndex] Camera index. Use 0 for single camera devices.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status getTimestampFrame(InputSource* handle,
                                     TimestampFrame* output,
                                     std::int32_t cameraIndex);

/*****************************************************************************
 * Prototype    : std::uint32_t getTimestampFrameBufferSize(InputSource* handle);
 * Description  : Gets the required TimestampFrame::bufferSize value in bytes
 *                for the current sensor resolution.
 *
 *                This size is for each timestamp array. Allocate this many
 *                bytes for TimestampFrame::onEvent and the same number of
 *                bytes for TimestampFrame::offEvent.
 *
 *                Call this after openDevice()/openFile() and applySensorSetting()
 *                before allocating TimestampFrame::onEvent and
 *                TimestampFrame::offEvent.
 *
 *                DVS resolution example (960 x 720):
 *                  getTimestampFrameBufferSize(handle) returns
 *                  960 * 720 * sizeof(std::uint32_t) = 2764800 bytes.
 * Parameters   : [handle] Input source handle returned by openDevice() or openFile().
 * Return Value : Required byte count for each timestamp array, or 0 when the
 *                handle is invalid.
 *****************************************************************************/
DELTA_SDK std::uint32_t getTimestampFrameBufferSize(InputSource* handle);

/*****************************************************************************
 * Prototype    : Status getClassicEvents(InputSource* handle,
 *                                ClassicEventList* output,
 *                                std::int32_t cameraIndex);
 * Description  : Gets parsed events in the classic DVS event format.
 *                Each event contains x, y, polarity, and timestamp.
 *                See ClassicEventList::eventCapacity for allocation guidance.
 * Parameters   : [handle]      Input source handle returned by openDevice() or openFile().
 *                [output]      Receives event data for one camera.
 *                [cameraIndex] Camera index. Use 0 for single camera devices.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status getClassicEvents(InputSource* handle,
                                    ClassicEventList* output,
                                    std::int32_t cameraIndex);

/*****************************************************************************
 * Prototype    : Status getCompactEvents(InputSource* handle,
 *                                        CompactEventList* output,
 *                                        std::int32_t cameraIndex);
 * Description  : Gets parsed events in the DVS compact event format.
 *                Each event contains packed x, y, and polarity data.
 *                Timestamp is stored once per generated frame as
 *                output->frameTimestamp.
 *                See CompactEventList::eventCapacity for allocation guidance.
 * Parameters   : [handle]      Input source handle returned by openDevice() or openFile().
 *                [output]      Receives compact event data for one camera.
 *                [cameraIndex] Camera index. Use 0 for single camera devices.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status getCompactEvents(InputSource* handle,
                                    CompactEventList* output,
                                    std::int32_t cameraIndex);

/*****************************************************************************
 * Common Processing Callback
 * ***************************************************************************/
/*****************************************************************************
 * Prototype    : Status setEventCountCallback(InputSource* handle,
 *                                             EventCountCallback callback,
 *                                             void* userData);
 * Description  : Registers a callback that receives total parsed event count
 *                approximately once per second while events are parsed from
 *                a live device stream or playback file.
 * Parameters   : [handle]   Input source handle returned by openDevice() or openFile().
 *                [callback] Callback function.
 *                [userData] User data passed to the callback.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status setEventCountCallback(InputSource* handle,
                                         EventCountCallback callback,
                                         void* userData);

/*****************************************************************************
 * Prototype    : Status setFrameCountCallback(InputSource* handle,
 *                                             FrameCountCallback callback,
 *                                             void* userData);
 * Description  : Registers a callback that receives total parsed frame-end
 *                count approximately once per second while events are parsed
 *                from a live device stream or playback file.
 * Parameters   : [handle]   Input source handle returned by openDevice() or openFile().
 *                [callback] Callback function.
 *                [userData] User data passed to the callback.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status setFrameCountCallback(InputSource* handle,
                                         FrameCountCallback callback,
                                         void* userData);

                                         
// Helper operators for combining OutputType flags.
// Users normally do not need to call these operators directly;
// they are used implicitly when writing expressions such as:
// OutputType::ColorFrame | OutputType::PolarityFrame
inline OutputType operator|(OutputType lhs, OutputType rhs)
{
    return static_cast<OutputType>(
        static_cast<std::uint32_t>(lhs) | static_cast<std::uint32_t>(rhs));
}

inline OutputType operator&(OutputType lhs, OutputType rhs)
{
    return static_cast<OutputType>(
        static_cast<std::uint32_t>(lhs) & static_cast<std::uint32_t>(rhs));
}

} // namespace delta

#endif
