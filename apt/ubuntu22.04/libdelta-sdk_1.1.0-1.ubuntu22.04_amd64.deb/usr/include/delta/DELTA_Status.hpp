#ifndef DELTA_STATUS_HPP
#define DELTA_STATUS_HPP

#include "DELTA_Types.hpp"

namespace delta {

enum class Status {
    Success = 0,

    Error_InvalidArgument = 1,
    Error_NotInitialized = 2,
    Error_NotStarted = 3,
    Error_AlreadyDone = 4,
    Error_Unsupported = 5,
    Error_Timeout = 6,
    Error_NoData = 7,
    Error_SystemRunning = 8,
    Error_UnsetBias = 9,
    Error_BufferTooSmall = 10,

    Error_DeviceBusy = 100,
    Error_InvalidDevice = 101,
    Error_DeviceNotFound = 102,
    Error_TooManyDevices = 103,
    Error_OpenUsbFailed = 104,
    Error_TransferFailed = 105,
    Error_ReadRegFailed = 106,
    Error_WriteRegFailed = 107,

    Error_FileOpenFailed = 200,
    Error_FileCreateFailed = 201,
    Error_FileReadFailed = 202,
    Error_FileWriteFailed = 203,
    Error_FileSeekFailed = 204,
    Error_InvalidFile = 205,
    Error_SaveFailed = 206,
    Error_DiskNoSpace = 207,

    Error_Common = 1000
};

DELTA_SDK const char* getStatusMessage(Status status);

} // namespace delta

#endif
