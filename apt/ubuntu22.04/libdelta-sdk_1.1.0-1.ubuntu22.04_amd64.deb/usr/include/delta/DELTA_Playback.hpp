/*****************************************************************************
 * File        : DELTA_Playback.hpp
 * Module      : DELTA Playback API
 * Description : Declares file playback connection functions for the DELTA SDK.
 *****************************************************************************/

#ifndef DELTA_PLAYBACK_HPP
#define DELTA_PLAYBACK_HPP

#include "DELTA_Status.hpp"
#include "DELTA_Types.hpp"

namespace delta {

/*****************************************************************************
 * Prototype    : Status openFile(const char* filePath, FileHandle* handle);
 * Description  : Opens a .dvs file and returns a playback handle.
 * Parameters   : [filePath] Path to the .dvs file.
 *                [handle]   Receives the opened playback file handle.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status openFile(const char* filePath,
                            FileHandle* handle);

/*****************************************************************************
 * Prototype    : Status closeFile(FileHandle handle);
 * Description  : Closes an opened playback file and releases its SDK resources.
 *                If playback is active, it is stopped automatically before the
 *                file is closed. Calling stopPlayback() beforehand is not
 *                required.
 * Parameters   : [handle] File handle returned by openFile().
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status closeFile(FileHandle handle);

/*****************************************************************************
 * Prototype    : Status startPlayback(FileHandle handle);
 * Description  : Starts playback from the opened file.
 * Parameters   : [handle] File handle returned by openFile().
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status startPlayback(FileHandle handle);

/*****************************************************************************
 * Prototype    : Status pausePlayback(FileHandle handle);
 * Description  : Pauses playback while preserving the current file position.
 *                After pausing, the internal frame buffer drains and subsequent
 *                calls to getColorFrame(), getClassicEvents(), getPolarityFrame(), and
 *                getTimestampFrame()
 *                return Status::Error_NoData. Call resumePlayback() to continue.
 * Parameters   : [handle] File handle returned by openFile().
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status pausePlayback(FileHandle handle);

/*****************************************************************************
 * Prototype    : Status resumePlayback(FileHandle handle);
 * Description  : Resumes playback from the paused file position.
 * Parameters   : [handle] File handle returned by openFile().
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status resumePlayback(FileHandle handle);

/*****************************************************************************
 * Prototype    : Status stopPlayback(FileHandle handle);
 * Description  : Stops playback and releases playback pipeline resources.
 * Parameters   : [handle] File handle returned by openFile().
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status stopPlayback(FileHandle handle);

/*****************************************************************************
 * Prototype    : Status setPlaybackMode(FileHandle handle,
 *                                       PlaybackMode mode);
 * Description  : Sets file playback mode.
 *                PlaybackMode::Once stops at the file end.
 *                PlaybackMode::Loop restarts from the beginning at the file end.
 * Parameters   : [handle] File handle returned by openFile().
 *                [mode]   Playback mode.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status setPlaybackMode(FileHandle handle,
                                   PlaybackMode mode);

/*****************************************************************************
 * Prototype    : Status getPlaybackMode(FileHandle handle,
 *                                       PlaybackMode* mode);
 * Description  : Gets the current file playback mode.
 * Parameters   : [handle] File handle returned by openFile().
 *                [mode]   Receives playback mode.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status getPlaybackMode(FileHandle handle,
                                   PlaybackMode* mode);

/*****************************************************************************
 * Playback Callback
 * ***************************************************************************/
/*****************************************************************************
 * Prototype    : Status setReadOverCallback(FileHandle handle,
 *                                           ReadOverCallback callback,
 *                                           void* userData);
 * Description  : Registers a callback that is called when single-play playback
 *                reaches the end of the file.
 * Parameters   : [handle]   File handle returned by openFile().
 *                [callback] Callback function.
 *                [userData] User data passed to the callback.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status setReadOverCallback(FileHandle handle,
                                       ReadOverCallback callback,
                                       void* userData);

} // namespace delta

#endif 
