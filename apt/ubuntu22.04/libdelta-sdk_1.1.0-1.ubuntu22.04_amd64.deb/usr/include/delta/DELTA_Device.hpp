/*****************************************************************************
 * File        : DELTA_Device.hpp
 * Module      : DELTA Device API
 * Description : Declares device discovery, connection, bias setting, and
 *               register access functions for the DELTA SDK.
 *****************************************************************************/

#ifndef DELTA_DEVICE_HPP
#define DELTA_DEVICE_HPP

#include "DELTA_Status.hpp"
#include "DELTA_Types.hpp"

namespace delta {

/*****************************************************************************
 * Prototype    : Status scanDevices(std::int32_t* deviceCount);
 * Description  : Scans connected DELTA-compatible USB devices.
 * Parameters   : [deviceCount] Receives the number of detected devices.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status scanDevices(std::int32_t* deviceCount);

/*****************************************************************************
 * Prototype    : Status getDeviceInfo(std::int32_t scanIndex,
 *                                      DeviceInfo* deviceInfo);
 * Description  : Gets information for a device found by scanDevices().
 * Parameters   : [scanIndex]  Zero-based index in the latest scan result.
 *                [deviceInfo]  Receives device information.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status getDeviceInfo(std::int32_t scanIndex,
                                 DeviceInfo* deviceInfo);

/*****************************************************************************
 * Prototype    : Status openDevice(std::int32_t deviceIndex,
 *                                  DeviceHandle* handle);
 * Description  : Opens a scanned device and returns a handle for later API calls.
 *                scanDevices() must be called first to populate the device list.
 *                deviceIndex must be a valid index from that scan result;
 *                passing an index without calling scanDevices() returns
 *                Status::Error_DeviceNotFound.
 * Parameters   : [deviceIndex]  Device index from the latest scan result.
 *                [handle]       Receives the opened device handle.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status openDevice(std::int32_t deviceIndex,
                              DeviceHandle* handle);

/*****************************************************************************
 * Prototype    : Status closeDevice(DeviceHandle handle);
 * Description  : Closes an opened device and releases its SDK resources.
 *                If the device is streaming, the stream is stopped automatically
 *                before the device is closed. Calling stopStream() beforehand
 *                is not required.
 * Parameters   : [handle] Device handle returned by openDevice().
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status closeDevice(DeviceHandle handle);

/*****************************************************************************
 * Prototype    : Status applySensorSetting(DeviceHandle handle,
 *                                          const char* settingFilePath);
 * Description  : Applies a sensor bias setting file to an opened device.
 *                The file must be a plain-text (.txt) bias configuration file.
 *                This function also sets the sensor stream version (Single/Stereo)
 *                read from the file header; call getStreamVersion() after this to
 *                confirm the detected version.
 *                Must be called before startStream(). Cannot be called while
 *                streaming is active (returns Status::Error_SystemRunning).
 *                This function blocks until all register writes complete.
 * Parameters   : [handle]          Device handle returned by openDevice().
 *                [settingFilePath] Path to the bias setting file (.txt).
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status applySensorSetting(DeviceHandle handle,
                                      const char* settingFilePath);

/*****************************************************************************
 * Prototype    : Status readSensorRegister(DeviceHandle handle,
 *                                          std::int32_t registerAddress,
 *                                          std::int32_t* value);
 * Description  : Reads a sensor register value from the opened device.
 *                Sensor register addresses use 16-bit format.
 *                Example: 0x300C.
 * Parameters   : [handle]          Device handle returned by openDevice().
 *                [registerAddress] Register address to read.
 *                [value]           Receives the register value.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status readSensorRegister(DeviceHandle handle,
                                      std::int32_t registerAddress,
                                      std::int32_t* value);

/*****************************************************************************
 * Prototype    : Status writeSensorRegister(DeviceHandle handle,
 *                                           std::int32_t registerAddress,
 *                                           std::int32_t value);
 * Description  : Writes a sensor register value to the opened device.
 *                Sensor register addresses use 16-bit format.
 *                Example register address : 0x300C.
 * Parameters   : [handle]          Device handle returned by openDevice().
 *                [registerAddress] Register address to write.
 *                [value]           Register value to write.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status writeSensorRegister(DeviceHandle handle,
                                       std::int32_t registerAddress,
                                       std::int32_t value);

/*****************************************************************************
 * Prototype    : Status readDeviceRegister(DeviceHandle handle,
 *                                          std::int32_t registerAddress,
 *                                          std::int32_t* value);
 * Description  : Reads a device logic register value from the opened device.
 *                Device register addresses use 8-bit format.
 *                Example register address : 0x37.
 * Parameters   : [handle]          Device handle returned by openDevice().
 *                [registerAddress] Register address to read.
 *                [value]           Receives the register value.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status readDeviceRegister(DeviceHandle handle,
                                      std::int32_t registerAddress,
                                      std::int32_t* value);

/*****************************************************************************
 * Prototype    : Status writeDeviceRegister(DeviceHandle handle,
 *                                           std::int32_t registerAddress,
 *                                           std::int32_t value);
 * Description  : Writes a device logic register value to the opened device.
 *                Device register addresses use 8-bit format.
 *                Example: 0x37.
 * Parameters   : [handle]          Device handle returned by openDevice().
 *                [registerAddress] Register address to write.
 *                [value]           Register value to write.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status writeDeviceRegister(DeviceHandle handle,
                                       std::int32_t registerAddress,
                                       std::int32_t value);

/*****************************************************************************
 * Prototype    : Status setUsbTimeout(DeviceHandle handle,
 *                                     std::int32_t timeoutMs);
 * Description  : Sets the USB transfer timeout in milliseconds.
 * Parameters   : [handle]    Device handle returned by openDevice().
 *                [timeoutMs] USB transfer timeout in milliseconds.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status setUsbTimeout(DeviceHandle handle,
                                 std::int32_t timeoutMs);

/*****************************************************************************
 * Prototype    : Status setUsbTransferSize(DeviceHandle handle,
 *                                          std::uint32_t transferSize);
 * Description  : Sets the USB transfer size in KB.
 *                Valid range is 2KB to 256KB.
 *                The SDK converts this value to the internal PPX value using
 *                the opened device's USB packet size.
 *                Example: 64 means 64KB per USB transfer.
 * Parameters   : [handle]       Device handle returned by openDevice().
 *                [transferSize] USB transfer size in KB.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status setUsbTransferSize(DeviceHandle handle,
                                      std::uint32_t transferSize);

/*****************************************************************************
 * Prototype    : Status getUsbTransferSize(DeviceHandle handle,
 *                                          std::uint32_t* transferSize);
 * Description  : Gets the USB transfer size in KB.
 *                Valid set range is 2KB to 256KB.
 * Parameters   : [handle]       Device handle returned by openDevice().
 *                [transferSize] Receives the USB transfer size in KB.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status getUsbTransferSize(DeviceHandle handle,
                                      std::uint32_t* transferSize);

/*****************************************************************************
 * Prototype    : Status setRawBufferCount(DeviceHandle handle,
 *                                         std::uint32_t bufferCount);
 * Description  : Sets the number of internal raw packet buffers used to hold
 *                USB input data before packet parsing.
 * Parameters   : [handle]      Device handle returned by openDevice().
 *                [bufferCount] Number of raw packet buffer nodes.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status setRawBufferCount(DeviceHandle handle,
                                     std::uint32_t bufferCount);

/*****************************************************************************
 * Prototype    : Status getRawBufferCount(DeviceHandle handle,
 *                                         std::uint32_t* bufferCount);
 * Description  : Gets the number of internal raw packet buffers used to hold
 *                USB input data before packet parsing.
 * Parameters   : [handle]      Device handle returned by openDevice().
 *                [bufferCount] Receives the number of raw packet buffer nodes.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status getRawBufferCount(DeviceHandle handle,
                                     std::uint32_t* bufferCount);

/*****************************************************************************
 * Prototype    : Status getStreamVersion(DeviceHandle handle,
 *                                  Version* version);
 * Description  : Gets the sensor stream version detected from the bias settings
 *                file header. Returns Version::Unknown if applySensorSetting()
 *                has not been called yet.
 *                Version::Single  = single-camera stream.
 *                Version::Stereo  = stereo-camera stream.
 * Parameters   : [handle]  Device handle returned by openDevice().
 *                [version] Receives the stream version.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status getStreamVersion(DeviceHandle handle,
                                    Version* version);

/*****************************************************************************
 * Prototype    : Status getResolution(DeviceHandle handle,
 *                                     std::int32_t* width,
 *                                     std::int32_t* height);
 * Description  : Gets the sensor resolution of an opened device.
 *                Call this after applySensorSetting(), because the resolution
 *                depends on the stream version read from the settings file.
 * Parameters   : [handle] Device handle returned by openDevice().
 *                [width]  Receives the sensor width in pixels.
 *                [height] Receives the sensor height in pixels.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status getResolution(DeviceHandle handle,
                                 std::int32_t* width,
                                 std::int32_t* height);

} // namespace delta

#endif
