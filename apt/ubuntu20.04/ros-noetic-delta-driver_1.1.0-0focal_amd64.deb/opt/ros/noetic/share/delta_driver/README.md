# delta_driver

A ROS1 driver for Delta series event cameras.

## The data format: Group AER

Delta cameras put out events in a format we call Group AER.

Classic AER sends `(x, y, t, p)` for every event, which uncompressed comes to
64 bits each. That is what `dvs_msgs`, common in ROS, carries.

Group AER raises the bandwidth efficiency along two axes.

**Space.** Eight adjacent rows within a column are expressed as a single bit
mask, and two such groups share one 32-bit word. A word therefore carries up to
16 events.

**Time.** Events do not carry individual time stamps. The time is updated once,
as one frame ends and the next begins, and every event in that frame shares it.

Where events are dense this works out to two bits per event, up to 32 times
less than uncompressed AER.

What actually limits an event camera is not the sensor but the transport. When
a burst of events exceeds the available bandwidth, data is truncated or lost.
Group AER puts far more events through the same bandwidth, so bursts do not
break the stream.

When you need finer timing than that, use an external trigger. It time stamps
in the sensor rather than on the host, so you can align with other equipment
regardless of the frame period.

## Decoding

An `EventPacket` carries a block of these words, not a list of events. The
`encoding` field says how to read them, and for this driver it is always
`group_aer`;
[event_camera_codecs](https://github.com/ros-event-camera/event_camera_codecs)
uses that to pick a decoder.

**The upstream release of that package has no `group_aer` decoder yet.**
Installing our ROS packages through apt pulls in a build that has one, so there
is nothing extra to do. If you build from source, use
[delta_event_camera_codecs](https://github.com/harold2232/event_camera_codecs)
until the decoder reaches upstream. Without it, nothing decodes and the only
sign is a line like this:

```
renderer: no decoder for encoding 'group_aer'
```

[delta_tools](../delta_tools/README.md) is installed alongside this driver and
is the quickest way to see the stream: it renders a live image and records
bags. On ROS1 it is also the only packaged renderer, as the upstream one has no
Noetic release.

The events can also be decoded and displayed using the following ROS packages:

- [event_camera_py](https://github.com/ros-event-camera/event_camera_py) for
  decoding in Python
- [event_camera_renderer](https://github.com/ros-event-camera/event_camera_renderer)
  to render images
- [event_camera_tools](https://github.com/ros-event-camera/event_camera_tools)
  to echo packets and measure rates

## Supported platforms

Tested with these cameras:

- [DELTA-01](https://nrv.kr/products/#delta01)
- [DELTA-10](https://nrv.kr/products/#delta10)

| ROS distribution | Ubuntu | Architecture | State |
| --- | --- | --- | --- |
| Noetic | 20.04 | amd64 | packaged |

arm64, including Jetson, is not packaged yet.

## Installation

### Ubuntu 20.04 + amd64 + ROS1 Noetic

```bash
sudo apt update && sudo apt install -y curl
sudo curl -fsSL https://nrvcorp.github.io/DELTA_SDK/apt/ubuntu20.04/nrv-archive-keyring.gpg -o /usr/share/keyrings/nrv-archive-keyring.gpg
echo "deb [signed-by=/usr/share/keyrings/nrv-archive-keyring.gpg] https://nrvcorp.github.io/DELTA_SDK/apt/ubuntu20.04/ ./" | sudo tee /etc/apt/sources.list.d/nrv.list
sudo apt update
sudo apt install ros-noetic-delta
```

That installs the driver, the tools, and the two event_camera packages.

## How to use

```bash
source /opt/ros/noetic/setup.bash
roslaunch delta_driver delta_driver.launch sensor_setting_path:=$(rospack find delta_driver)/config/sensor/Delta_01_1000FPS.txt
```

Use `Delta_01_1000FPS.txt` for a DELTA-01 and `Delta_10_2000FPS.txt` for a
DELTA-10. `sensor_setting_path` is required, and the section on the sensor
setting file below explains what it holds.

The camera opens and starts streaming as the node comes up. There is no
separate start command; stop it with `Ctrl+C`.

### Checking it works

Every `statistics_interval` seconds the driver prints a line like this:

```
delta_driver: in xx.x MB/s (xxxx chunks/s) | out xx.x MB/s (xxx msgs/s) | queue peak x/200
```

`in` is what arrived from the camera and `out` is what was published. **The two
should match**; a gap between them means payload was dropped on the way out.
`queue peak` rising toward its limit means whatever is subscribing cannot keep
up.

From another terminal:

```bash
rostopic hz /delta_driver/events
```

Covering and uncovering the lens should change the rate.

### With a live image

```bash
roslaunch delta_tools delta_viewer_ros1.launch rqt:=true sensor_setting_path:=$(rospack find delta_driver)/config/sensor/Delta_01_1000FPS.txt
```

### Recording

```bash
rosbag record /delta_driver/events
```

Packets are recorded encoded, which is far smaller than storing decoded events.

### In the same process as your own node

Between two processes, every message is serialised, sent through the network
stack and deserialised again. At the rates this camera produces that costs real
CPU, and under load it is where messages get dropped.

A nodelet avoids it. Start the driver in a manager:

```bash
roslaunch delta_driver delta_driver_nodelet.launch sensor_setting_path:=$(rospack find delta_driver)/config/sensor/Delta_01_1000FPS.txt
```

Then load your own nodelet into that same manager, and it is handed a pointer
to each message instead of a copy:

```xml
<node pkg="nodelet" type="nodelet" name="my_processor"
      args="load my_package/MyNodelet delta_manager" />
```

The plain node and the nodelet run the same code and take the same parameters,
so nothing else changes.

Recording does not benefit from this on Noetic, which has no nodelet recorder;
`rosbag record` is a separate process either way.

## Published topic

| Topic | Type |
| --- | --- |
| `~events` | `event_camera_msgs/EventPacket` |

With the default node name that is `/delta_driver/events`.

## Reading the events in your own node

```cpp
#include <event_camera_codecs/decoder_factory.h>
#include <event_camera_codecs/event_processor.h>
#include <event_camera_msgs/EventPacket.h>

class MyProcessor : public event_camera_codecs::EventProcessor {
public:
  // polarity is 0 for OFF and 1 for ON; t is nanoseconds
  void eventCD(uint64_t t, uint16_t x, uint16_t y, uint8_t polarity) override {
  }
  bool eventExtTrigger(uint64_t t, uint8_t edge, uint8_t id) override { return true; }
  void finished() override {}
  void rawData(const char *, size_t) override {}
};

MyProcessor processor;
event_camera_codecs::DecoderFactory<event_camera_msgs::EventPacket, MyProcessor> factory;

void callback(const event_camera_msgs::EventPacket::ConstPtr & msg) {
  auto decoder = factory.getInstance(*msg);
  if (!decoder) { return; }        // encoding has no decoder installed
  decoder->decode(*msg, &processor);
}
```

`eventExtTrigger` has to be overridden because the interface requires it, but
this decoder does not call it; see the note under external triggering.

## Parameters

| Parameter | Default | Meaning |
| --- | --- | --- |
| `sensor_setting_path` | `""` | **Required.** Sensor setting file. See below. |
| `device_index` | `0` | Which camera to open when several are attached. |
| `serial_number` | `""` | Open by serial instead of by index. |
| `encoding` | `group_aer` | Written into the message. Leave it alone. |
| `frame_id` | `delta_camera` | `header.frame_id` of published messages. |
| `message_threshold_time_ms` | `10` | Publish at least this often. |
| `message_threshold_size_bytes` | `1048576` | Publish once a message reaches this size. |
| `publish_queue_size` | `1000` | Outgoing queue. |
| `max_queued_messages` | `200` | How many messages may wait before the driver drops them. |
| `statistics_interval` | `5.0` | Seconds between rate printouts. `0` disables. |
| `usb_timeout_ms` | `5000` | USB read timeout. |
| `usb_transfer_size_kb` | `-1` | `-1` keeps the SDK default. |
| `raw_buffer_count` | `-1` | `-1` keeps the SDK default. |

A message is published as soon as either threshold is reached, so the two
together set the trade-off between latency and per-message overhead.

## Sensor setting file

`sensor_setting_path` points at a sensor register script. It is not only
biases: it also carries the PLL, the streaming mode, and the external sync and
trigger registers. The driver writes these to the sensor before streaming
starts, so **this file is how the camera is configured**.

Files ship with the package:

```
$(rospack find delta_driver)/config/sensor/
├── Delta_01_1000FPS.txt
└── Delta_10_2000FPS.txt
```

To change the sensor configuration, copy one of these and edit the copy. The
installed files are replaced on update.

### External triggering

External trigger is enabled through the registers in this file, and makes the
sensor time stamp against an external signal rather than against the host
clock.

**The `group_aer` decoder does not surface trigger events through
`eventExtTrigger` yet.** The interface requires the method, but this decoder
only ever calls `eventCD`. Trigger events are visible in the stream itself.

Which registers to set, and the pin assignments, are in the sensor
documentation at <https://nrv.kr>. Contact <sales@nrv.kr> for a setting file
prepared for a particular trigger configuration.

## About timestamps

`header.stamp` and `time_base` are the **host clock reading when the driver
began filling that message**, not a sensor time stamp. The times the decoder
reports are that base plus the sensor's offset within the message.

This matters when synchronising with other sensors: the base carries whatever
delay the USB transfer and the host scheduler introduced. For tighter
synchronisation, use the external trigger described above, which timestamps in
the sensor rather than on the host.

## Camera permissions

`libdelta-sdk` installs a udev rule, so the camera opens without `sudo`. It
takes effect on installation; no reboot or replug is needed.

## Troubleshooting

**`'sensor_setting_path' parameter is required`** — the parameter was not set.
It has no default because the right file depends on the camera model.

**`no decoder for encoding 'group_aer'`** — the `event_camera_codecs` in use has
no `group_aer` decoder. See the top of this file.

**No events arrive** — check that the camera enumerates (`lsusb`), and that the
setting file matches the camera model. `statistics_interval` printouts show
whether the driver is receiving anything at all.

## License

Proprietary. Contact <sales@nrv.kr>.
