import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    config = os.path.join(
        get_package_share_directory('delta_driver'), 'config', 'delta_driver_ros2.yaml')

    return LaunchDescription([
        DeclareLaunchArgument('sensor_setting_path', default_value=''),
        DeclareLaunchArgument('device_index', default_value='0'),
        Node(
            package='delta_driver',
            executable='delta_driver_node',
            name='delta_driver',
            output='screen',
            parameters=[
                config,
                {
                    'sensor_setting_path': ParameterValue(
                        LaunchConfiguration('sensor_setting_path'), value_type=str),
                    'device_index': ParameterValue(
                        LaunchConfiguration('device_index'), value_type=int),
                },
            ],
        ),
    ])
