#pragma once

#include <string>

#ifdef USING_ROS_1

#include <ros/ros.h>
#include <event_camera_msgs/EventPacket.h>

#else

#include <rclcpp/rclcpp.hpp>
#include <event_camera_msgs/msg/event_packet.hpp>

#endif

namespace delta_driver {

#ifdef USING_ROS_1

using EventPacketMsg = event_camera_msgs::EventPacket;

using NodeHandle = ros::NodeHandle;

template <typename T>
T getParam(ros::NodeHandle & nh, const std::string & name, const T & defaultValue)
{
  T value;
  nh.param(name, value, defaultValue);
  return value;
}

inline uint64_t nowNanoseconds(ros::NodeHandle &) { return ros::Time::now().toNSec(); }

#define DELTA_LOG_INFO(node, ...) ROS_INFO(__VA_ARGS__)
#define DELTA_LOG_WARN(node, ...) ROS_WARN(__VA_ARGS__)
#define DELTA_LOG_ERROR(node, ...) ROS_ERROR(__VA_ARGS__)

#else

using EventPacketMsg = event_camera_msgs::msg::EventPacket;

using NodeHandle = rclcpp::Node;

template <typename T>
T getParam(rclcpp::Node & node, const std::string & name, const T & defaultValue)
{
  if (!node.has_parameter(name)) {
    node.declare_parameter<T>(name, defaultValue);
  }
  return node.get_parameter(name).get_value<T>();
}

inline uint64_t nowNanoseconds(rclcpp::Node & node)
{
  return static_cast<uint64_t>(node.now().nanoseconds());
}

#define DELTA_LOG_INFO(node, ...) RCLCPP_INFO((node).get_logger(), __VA_ARGS__)
#define DELTA_LOG_WARN(node, ...) RCLCPP_WARN((node).get_logger(), __VA_ARGS__)
#define DELTA_LOG_ERROR(node, ...) RCLCPP_ERROR((node).get_logger(), __VA_ARGS__)

#endif

}  // namespace delta_driver
