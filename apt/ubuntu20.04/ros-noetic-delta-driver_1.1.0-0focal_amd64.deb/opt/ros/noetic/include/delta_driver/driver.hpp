#pragma once

#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <deque>
#include <memory>
#include <mutex>
#include <string>
#include <thread>

#include "delta_driver/delta_wrapper.hpp"
#include "delta_driver/ros_compat.hpp"

namespace delta_driver {

class Driver
{
public:
  explicit Driver(NodeHandle & node);
  ~Driver();

  Driver(const Driver &) = delete;
  Driver & operator=(const Driver &) = delete;

  bool initialize();
  void shutdown();

private:
  struct Stats
  {
    uint64_t bytesRecv = 0;
    uint64_t chunksRecv = 0;
    uint64_t bytesSent = 0;
    uint64_t msgsSent = 0;
    size_t maxQueueSize = 0;
  };

  void onRawChunk(int cameraIndex, const uint8_t * data, uint32_t size);
  void queuePacket();
  void runThread();
  bool hasSubscribers();
  void printStatistics();

  NodeHandle & node_;

#ifdef USING_ROS_1
  ros::Publisher publisher_;
#else
  rclcpp::Publisher<EventPacketMsg>::SharedPtr publisher_;
#endif

  std::unique_ptr<DeltaWrapper> camera_;

  std::string frameId_;
  std::string encoding_;
  int publishQueueSize_ = 1000;
  uint64_t thresholdTimeNs_ = 10ULL * 1000ULL * 1000ULL;
  size_t thresholdSizeBytes_ = 1024 * 1024;

  std::mutex pendingMutex_;
  std::unique_ptr<EventPacketMsg> pending_;
  uint64_t pendingStartNs_ = 0;
  uint64_t sequence_ = 0;

  std::mutex queueMutex_;
  std::condition_variable queueCv_;
  std::deque<std::unique_ptr<EventPacketMsg>> queue_;
  size_t maxQueuedMessages_ = 200;
  uint64_t droppedMessages_ = 0;

  std::mutex statsMutex_;
  Stats stats_;
  double statisticsInterval_ = 5.0;
  uint64_t lastStatsNs_ = 0;

  std::thread publishThread_;
  std::atomic<bool> running_{false};
};

}  // namespace delta_driver
