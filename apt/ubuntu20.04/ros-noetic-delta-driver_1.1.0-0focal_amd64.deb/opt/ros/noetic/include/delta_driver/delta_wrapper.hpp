#pragma once

#include <atomic>
#include <cstdint>
#include <functional>
#include <mutex>
#include <string>

#include <DELTA_SDK.hpp>

namespace delta_driver {

struct DeltaConfig
{
  int deviceIndex = 0;
  std::string serialNumber;
  std::string sensorSettingPath;
  int usbTimeoutMs = -1;
  int usbTransferSizeKb = -1;
  int rawBufferCount = -1;
};

using RawChunkCallback =
  std::function<void(int cameraIndex, const uint8_t * data, uint32_t size)>;

class DeltaWrapper
{
public:
  explicit DeltaWrapper(DeltaConfig config);
  ~DeltaWrapper();

  DeltaWrapper(const DeltaWrapper &) = delete;
  DeltaWrapper & operator=(const DeltaWrapper &) = delete;

  bool open();
  bool start();
  void stop();
  void close();

  void setRawChunkCallback(RawChunkCallback callback);

  bool isStreaming() const { return streaming_.load(); }
  std::string getLastError() const;
  int getWidth() const { return width_; }
  int getHeight() const { return height_; }
  std::string getSerialNumber() const { return serialNumber_; }
  std::string getDeviceName() const;

private:
  static void rawStreamTrampoline(
    void * userData, std::int32_t cameraIndex, const std::uint8_t * data, std::uint32_t size);

  bool selectDevice(std::int32_t deviceCount, std::int32_t * selectedIndex);
  bool checkStatus(delta::Status status, const char * context);
  void setError(const std::string & message);

  DeltaConfig config_;
  delta::DeviceHandle handle_ = nullptr;
  delta::DeviceType deviceType_ = delta::DeviceType::Delta_10;
  std::string serialNumber_;
  int width_ = 0;
  int height_ = 0;

  RawChunkCallback callback_;
  std::atomic<bool> streaming_{false};

  mutable std::mutex errorMutex_;
  std::string lastError_;
};

}  // namespace delta_driver
