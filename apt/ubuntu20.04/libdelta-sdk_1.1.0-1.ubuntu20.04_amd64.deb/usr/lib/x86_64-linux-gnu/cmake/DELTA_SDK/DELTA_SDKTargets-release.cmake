#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "DELTA_SDK::DELTA_SDK" for configuration "Release"
set_property(TARGET DELTA_SDK::DELTA_SDK APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(DELTA_SDK::DELTA_SDK PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "opencv_core;opencv_calib3d;opencv_imgproc;opencv_highgui;opencv_imgcodecs;opencv_videoio"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libDELTA_SDK.so"
  IMPORTED_SONAME_RELEASE "libDELTA_SDK.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS DELTA_SDK::DELTA_SDK )
list(APPEND _IMPORT_CHECK_FILES_FOR_DELTA_SDK::DELTA_SDK "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libDELTA_SDK.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
