/*****************************************************************************
 * File        : DELTA_LiveStream.hpp
 * Module      : DELTA Live Stream API
 * Description : Declares live USB stream control and raw packet functions for
 *               the DELTA SDK.
 *****************************************************************************/

#ifndef DELTA_LIVE_STREAM_HPP
#define DELTA_LIVE_STREAM_HPP

#include "DELTA_Status.hpp"
#include "DELTA_Types.hpp"

namespace delta {

/*****************************************************************************
 * Prototype    : Status startStream(DeviceHandle handle);
 * Description  : Starts live streaming for an opened device.
 * Parameters   : [handle] Device handle returned by openDevice().
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status startStream(DeviceHandle handle);

/*****************************************************************************
 * Prototype    : Status stopStream(DeviceHandle handle);
 * Description  : Stops live streaming for an opened device.
 * Parameters   : [handle] Device handle returned by openDevice().
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status stopStream(DeviceHandle handle);

/*****************************************************************************
 * Prototype    : Status getRawPacket(DeviceHandle handle,
 *                                     std::uint8_t* buffer,
 *                                     std::uint32_t bufferSize,
 *                                     std::uint32_t* readSize);
 * Description  : Reads one raw USB packet from the opened device.
 * Parameters   : [handle]     Device handle returned by openDevice().
 *                [buffer]     Buffer that receives raw data.
 *                [bufferSize] Size of the buffer in bytes.
 *                [readSize]   Receives the number of bytes read.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status getRawPacket(DeviceHandle handle,
                                std::uint8_t* buffer,
                                std::uint32_t bufferSize,
                                std::uint32_t* readSize);

/*****************************************************************************
 * Continuous Raw Stream
 *
 * Unlike getRawPacket(), which performs a single self-contained read and
 * cannot be used while streaming, these functions expose the uninterrupted
 * raw USB word stream produced during startStream(). The byte layout is the
 * sensor's native grouped-AER wire format and matches the contents of a .dvs
 * file written by the raw saving API.
 *
 * Two consumption models are available and may be used independently:
 *   1. setRawStreamCallback() : zero-copy, invoked from the SDK read thread.
 *   2. startRawStream() + getRawStream() : polling, SDK buffers chunks.
 * ***************************************************************************/

/*****************************************************************************
 * Prototype    : Status setRawStreamCallback(DeviceHandle handle,
 *                                            RawStreamCallback callback,
 *                                            void* userData);
 * Description  : Registers a callback that receives every raw USB chunk while
 *                streaming. The callback runs on the SDK read thread and the
 *                data pointer is valid only for the duration of the call, so
 *                the callee must copy what it needs and return promptly.
 *                Pass nullptr as callback to unregister.
 * Parameters   : [handle]   Device handle returned by openDevice().
 *                [callback] Callback function, or nullptr to unregister.
 *                [userData] User data passed to the callback.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status setRawStreamCallback(DeviceHandle handle,
                                        RawStreamCallback callback,
                                        void* userData);

/*****************************************************************************
 * Prototype    : Status startRawStream(DeviceHandle handle,
 *                                       std::uint32_t chunkCount);
 * Description  : Starts buffering raw USB chunks inside the SDK so they can be
 *                retrieved with getRawStream(). When the buffer is full the
 *                oldest chunk is discarded and the drop counter is increased.
 *                May be called before or after startStream().
 * Parameters   : [handle]     Device handle returned by openDevice().
 *                [chunkCount] Number of raw chunks to buffer. 0 selects the
 *                             default of 64.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status startRawStream(DeviceHandle handle,
                                  std::uint32_t chunkCount);

/*****************************************************************************
 * Prototype    : Status getRawStream(DeviceHandle handle,
 *                                     std::uint8_t* buffer,
 *                                     std::uint32_t bufferSize,
 *                                     std::uint32_t* readSize,
 *                                     std::int32_t cameraIndex);
 * Description  : Copies one buffered raw chunk into the caller's buffer.
 *                Returns Status::Error_NoData when no chunk is pending, and
 *                Status::Error_BufferTooSmall when the pending chunk does not
 *                fit; in the latter case readSize receives the required size
 *                and the chunk is kept for the next call.
 * Parameters   : [handle]      Device handle returned by openDevice().
 *                [buffer]      Buffer that receives raw data.
 *                [bufferSize]  Size of the buffer in bytes.
 *                [readSize]    Receives the number of bytes written.
 *                [cameraIndex] Camera index. Use 0 for single camera devices.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status getRawStream(DeviceHandle handle,
                                std::uint8_t* buffer,
                                std::uint32_t bufferSize,
                                std::uint32_t* readSize,
                                std::int32_t cameraIndex);

/*****************************************************************************
 * Prototype    : Status getRawStreamDropCount(DeviceHandle handle,
 *                                              std::uint64_t* dropCount,
 *                                              std::int32_t cameraIndex);
 * Description  : Gets how many raw chunks have been discarded because the
 *                caller did not drain the buffer fast enough.
 * Parameters   : [handle]      Device handle returned by openDevice().
 *                [dropCount]   Receives the cumulative dropped chunk count.
 *                [cameraIndex] Camera index. Use 0 for single camera devices.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status getRawStreamDropCount(DeviceHandle handle,
                                         std::uint64_t* dropCount,
                                         std::int32_t cameraIndex);

/*****************************************************************************
 * Prototype    : Status stopRawStream(DeviceHandle handle);
 * Description  : Stops raw chunk buffering and releases the buffer. Any
 *                callback registered with setRawStreamCallback() is unaffected.
 * Parameters   : [handle] Device handle returned by openDevice().
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status stopRawStream(DeviceHandle handle);

/*****************************************************************************
 * Live Stream Callback
 * ***************************************************************************/
/*****************************************************************************
 * Prototype    : Status setDataRateCallback(DeviceHandle handle,
 *                                           DataRateCallback callback,
 *                                           void* userData);
 * Description  : Registers a callback that receives USB data rate in KB/s.
 * Parameters   : [handle]   Device handle returned by openDevice().
 *                [callback] Callback function.
 *                [userData] User data passed to the callback.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status setDataRateCallback(DeviceHandle handle,
                                       DataRateCallback callback,
                                       void* userData);

/*****************************************************************************
 * Prototype    : Status setFrameRateCallback(DeviceHandle handle,
 *                                            FrameRateCallback callback,
 *                                            void* userData);
 * Description  : Registers a callback that receives generated frame rate in FPS.
 * Parameters   : [handle]   Device handle returned by openDevice().
 *                [callback] Callback function.
 *                [userData] User data passed to the callback.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status setFrameRateCallback(DeviceHandle handle,
                                        FrameRateCallback callback,
                                        void* userData);

} // namespace delta

#endif
