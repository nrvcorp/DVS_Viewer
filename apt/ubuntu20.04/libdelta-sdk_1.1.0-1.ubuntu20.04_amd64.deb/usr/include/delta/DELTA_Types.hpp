#ifndef DELTA_TYPES_HPP
#define DELTA_TYPES_HPP

#include <cstdint>

#define DELTA_MAX_DEVICE_COUNT 2
#define DELTA_DEVICE_DESCRIPTION_LENGTH 256
#define DELTA_DEFAULT_EVENT_CAPACITY (512 * 1024)

namespace delta {

// DeviceHandle and FileHandle are both aliases for InputSource*, but carry
// different semantic intent:
//   - DeviceHandle : returned by openDevice(); pass to device-only functions
//                    (startStream, applySensorSetting, register access, etc.)
//   - FileHandle   : returned by openFile(); pass to file-only functions
//                    (startPlayback, pausePlayback, setPlaybackMode, etc.)
//   - InputSource* : accepted by functions that work with either source type
//                    (setFrameGeneration, getColorFrame, getClassicEvents,
//                     getPolarityFrame, getTimestampFrame, startFrameSaving, etc.)
struct InputSource;

using DeviceHandle = InputSource*;
using FileHandle = InputSource*;

enum class InputSourceType {
    File = 0,
    Device = 1
};

enum class PlaybackMode {
    Once,
    Loop
};

enum class ColorFormat {
    Gray = 0,
    RGB = 1
};

struct Color {
    std::uint8_t r;
    std::uint8_t g;
    std::uint8_t b;
};

struct EventColor {
    Color onEvent;    // Color used for ON events.
    Color offEvent;   // Color used for OFF events.
    Color noEvent;    // Color used for pixels without events.
};

enum class DeviceType {
    Delta_01 = 0,
    Delta_10 = 1
};

struct DeviceInfo {
    std::int32_t index;
    std::int32_t portID;
    char serialNumber[64];
    DeviceType type;
    std::uint32_t usbPacketSize;
    char description[DELTA_DEVICE_DESCRIPTION_LENGTH];
};

enum class Version {
    Unknown = 0,
    Single = 1,
    Stereo = 17    // Single | (1 << 4)
};

// Metadata for one generated output frame.
// For ClassicEventList, width and height describe the event coordinate range,
// not the number of events in the output.
struct FrameInfo {
    Version version;             // Sensor data format used for this output.
    std::int32_t width;          // Output width in pixels.
    std::int32_t height;         // Output height in pixels.
    std::int32_t cameraIndex;    // Camera stream index that produced this output.
    std::uint32_t frameIndex;    // Monotonic frame index assigned by the SDK.
};

/*****************************************************************************
 * Structure   : ClassicEvent
 * Description : Classic DVS event format for compatibility-oriented output.
 *
 *               Layout:
 *                 [x][y][polarity][timestamp]
 *
 *               Polarity encoding matches the sensor output:
 *                 0 = ON  event (log-brightness increase)
 *                 1 = OFF event (log-brightness decrease)
 *
 *               Timestamp is in microseconds, relative to the start of the
 *               stream. The counter wraps at UINT32_MAX (~4295 seconds).
 *****************************************************************************/
struct ClassicEvent {
    std::uint16_t x;
    std::uint16_t y;
    std::uint8_t  polarity;    // 0 = ON, 1 = OFF (sensor convention)
    std::uint32_t timestamp;   // Microseconds since stream start.
};

/*****************************************************************************
 * Structure   : ClassicEventList
 * Description : Classic DVS event list output.
 *
 *               This format stores only pixels where events occurred in the
 *               current generated output. Each event carries its own x, y,
 *               polarity, and timestamp fields.
 *
 *               Shape:
 *                 events[0] = [x][y][polarity][timestamp]
 *                 events[1] = [x][y][polarity][timestamp]
 *                 ...
 *                 events[eventCount - 1]
 *
 *               eventCapacity is the number of ClassicEvent elements allocated
 *               in events, not a byte size.
 *
 *               Recommended default:
 *                 eventCapacity = DELTA_DEFAULT_EVENT_CAPACITY
 *
 *               If FrameMode::EventCountBased is used:
 *                 eventCapacity should be greater than or equal to
 *                 eventsPerFrame.
 *
 *               Memory usage:
 *                 eventCapacity * sizeof(ClassicEvent)
 *****************************************************************************/
struct ClassicEventList {
    FrameInfo header;            // Filled by the SDK.
    ClassicEvent* events;        // Caller-owned array that receives parsed events.
    std::int32_t eventCapacity;  // Input: number of ClassicEvent elements allocated in events.
    std::int32_t eventCount;     // Output: number of ClassicEvent elements written by the SDK.
};

/*****************************************************************************
 * Structure   : CompactEvent
 * Description : DVS-optimized lightweight event format.
 *
 *               One CompactEvent is intended to be 4 bytes:
 *                 x        : 15 bits
 *                 polarity : 1 bit  (0 = ON, 1 = OFF)
 *                 y        : 16 bits
 *
 *               This format does not store timestamp per event. The timestamp
 *               is stored once per generated frame in
 *               CompactEventList::frameTimestamp.
 *****************************************************************************/
struct CompactEvent {
    std::uint16_t x : 15;
    std::uint16_t polarity : 1;
    std::uint16_t y;
};

static_assert(sizeof(CompactEvent) == 4, "CompactEvent must be 4 bytes.");

/*****************************************************************************
 * Structure   : CompactEventList
 * Description : DVS-optimized compact event list output.
 *
 *               This format stores only pixels where events occurred in the
 *               current generated output. Each event carries x, y, and polarity
 *               in one 4-byte CompactEvent value. The frame timestamp is stored
 *               once as frameTimestamp.
 *
 *               Shape:
 *                 events[0] = [x][polarity][y]
 *                 events[1] = [x][polarity][y]
 *                 ...
 *                 events[eventCount - 1]
 *
 *               eventCapacity is the number of CompactEvent elements allocated
 *               in events, not a byte size.
 *
 *               Recommended default:
 *                 eventCapacity = DELTA_DEFAULT_EVENT_CAPACITY
 *
 *               If FrameMode::EventCountBased is used:
 *                 eventCapacity should be greater than or equal to
 *                 eventsPerFrame.
 *
 *               Memory usage:
 *                 eventCapacity * sizeof(CompactEvent)
 *****************************************************************************/
struct CompactEventList {
    FrameInfo header;                    // Filled by the SDK.
    std::uint32_t frameTimestamp;        // Timestamp for this generated frame.
    CompactEvent* events;                // Caller-owned array that receives compact events.
    std::int32_t eventCapacity;          // Input: number of CompactEvent elements allocated in events.
    std::int32_t eventCount;             // Output: number of CompactEvent elements written by the SDK.
};

/*****************************************************************************
 * Structure   : PolarityFrame
 * Description : Per-pixel polarity output for one generated frame.
 *
 *               Shape:
 *                 startAddress[index] = polarity
 *                 index = y * width + x
 *
 *               Per-pixel value:
 *                 0  = ON event
 *                 1  = OFF event
 *                -1  = no event
 *
 *               bufferSize is counted in bytes.
 *
 *               DVS resolution example (960 x 720):
 *                 allocate 960 * 720 = 691200 bytes.
 *****************************************************************************/
struct PolarityFrame {
    FrameInfo header;            // Filled by the SDK.
    std::int8_t* startAddress;   // Caller-owned output array start address.
    std::uint32_t bufferSize;    // Input: allocated output buffer size in bytes.
};

/*****************************************************************************
 * Structure   : TimestampFrame
 * Description : Per-pixel timestamp output for one generated frame.
 *
 *               Shape:
 *                 onEvent[index]  = latest ON event timestamp at pixel (x, y)
 *                 offEvent[index] = latest OFF event timestamp at pixel (x, y)
 *                 index = y * width + x
 *
 *               Per-pixel value:
 *                 timestamp in microseconds, or 0 when no event is stored.
 *
 *               bufferSize is counted in bytes for each timestamp array.
 *               Allocate bufferSize bytes for onEvent and the same number of
 *               bytes for offEvent.
 *
 *               DVS resolution example (960 x 720):
 *                 allocate 960 * 720 * sizeof(uint32_t) = 2764800 bytes
 *                 for onEvent, and the same size for offEvent.
 *****************************************************************************/
struct TimestampFrame {
    FrameInfo header;            // Filled by the SDK.
    std::uint32_t* onEvent;      // Caller-owned array for ON event timestamps (microseconds).
    std::uint32_t* offEvent;     // Caller-owned array for OFF event timestamps (microseconds).
    std::uint32_t bufferSize;    // Input: allocated size in bytes for each timestamp array.
    std::uint32_t lastTimestamp; // Output: latest timestamp observed for this frame (microseconds).
};

/*****************************************************************************
 * Structure   : ColorFrame
 * Description : Rendered color output for one generated frame.
 *
 *               Grayscale shape:
 *                 startAddress[index] = grayscale intensity
 *                 index = y * width + x
 *
 *               RGB shape:
 *                 startAddress[index * 3 + 0] = red
 *                 startAddress[index * 3 + 1] = green
 *                 startAddress[index * 3 + 2] = blue
 *                 index = y * width + x
 *
 *               Default format:
 *                 ColorFrame defaults to ColorFormat::Gray.
 *                 In grayscale mode, each pixel uses one uint8_t value:
 *                   0   = black
 *                   255 = white
 *
 *               RGB format:
 *                 Use setColorFormat(handle, ColorFormat::RGB) before calling
 *                 getColorFrame(). In RGB mode, each pixel uses three uint8_t
 *                 values in red, green, blue order.
 *
 *               bufferSize is counted in bytes.
 *
 *               DVS resolution example (960 x 720, grayscale):
 *                 allocate 960 * 720 = 691200 bytes.
 *
 *               DVS resolution example (960 x 720, RGB):
 *                 allocate 960 * 720 * 3 = 2073600 bytes.
 *****************************************************************************/
struct ColorFrame {
    FrameInfo header;            // Filled by the SDK.
    ColorFormat colorFormat;     // Filled by the SDK.
    std::uint8_t* startAddress;  // Caller-owned output image buffer start address.
    std::uint32_t bufferSize;    // Input: allocated output buffer size in bytes.
};

// Callbacks are invoked from an internal SDK thread, not the calling thread.
// Callback implementations must be thread-safe. Do not call blocking SDK
// functions (e.g., saveRawByTime) from inside a callback.
using DataRateCallback  = void (*)(void* userData, double kilobytesPerSecond);
using RawStreamCallback = void (*)(void* userData, std::int32_t cameraIndex,
                                   const std::uint8_t* data, std::uint32_t size);
using EventCountCallback = void (*)(void* userData, std::uint64_t totalEvents);
using FrameCountCallback = void (*)(void* userData, std::uint64_t totalFrames);
using FrameRateCallback = void (*)(void* userData, std::int32_t framesPerSecond);
using ReadOverCallback  = void (*)(void* userData);

#ifdef _WIN32
#ifdef DELTA_SDK_EXPORTS
#define DELTA_SDK __declspec(dllexport)
#else
#define DELTA_SDK __declspec(dllimport)
#endif
#else
#define DELTA_SDK __attribute__((visibility("default")))
#endif

} // namespace delta

#endif
