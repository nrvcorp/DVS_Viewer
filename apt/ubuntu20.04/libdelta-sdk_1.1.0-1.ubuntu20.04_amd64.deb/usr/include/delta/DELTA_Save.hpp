#ifndef DELTA_SAVE_HPP
#define DELTA_SAVE_HPP

#include "DELTA_Processing.hpp"
#include "DELTA_Status.hpp"
#include "DELTA_Types.hpp"

namespace delta {

/*****************************************************************************
 * Prototype    : Status startRawSaving(DeviceHandle handle,
 *                                      const char* saveDirectory);
 * Description  : Starts saving raw device data to the specified directory.
 *                startStream() must be called before this function.
 *                Saved file format: .dvs (readable via openFile()).
 * Parameters   : [handle]        Device handle returned by openDevice().
 *                [saveDirectory] Directory where raw data will be saved.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status startRawSaving(DeviceHandle handle,
                                  const char* saveDirectory);

/*****************************************************************************
 * Prototype    : Status stopRawSaving(DeviceHandle handle);
 * Description  : Stops raw data saving for the opened device.
 * Parameters   : [handle] Device handle returned by openDevice().
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status stopRawSaving(DeviceHandle handle);

// saveRawBy* functions require startStream() to have been called first.
// All saveRawBy* functions block (do not return) until saving completes.
// Saved file format: .dvs (readable via openFile()).

/*****************************************************************************
 * Prototype    : Status saveRawByTime(DeviceHandle handle,
 *                                     const char* saveDirectory,
 *                                     std::int32_t durationMs);
 * Description  : Saves raw device data for the specified duration.
 *                Blocks until saving completes.
 * Parameters   : [handle]        Device handle returned by openDevice().
 *                [saveDirectory] Directory where raw data will be saved.
 *                [durationMs]    Saving duration in milliseconds.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status saveRawByTime(DeviceHandle handle,
                                 const char* saveDirectory,
                                 std::int32_t durationMs);

/*****************************************************************************
 * Prototype    : Status saveRawBySize(DeviceHandle handle,
 *                                     const char* saveDirectory,
 *                                     std::uint64_t bytes);
 * Description  : Saves raw device data until the accumulated raw packet byte
 *                count reaches the specified value. Blocks until saving completes.
 * Parameters   : [handle]        Device handle returned by openDevice().
 *                [saveDirectory] Directory where raw data will be saved.
 *                [bytes]         Target raw packet byte count.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status saveRawBySize(DeviceHandle handle,
                                 const char* saveDirectory,
                                 std::uint64_t bytes);

/*****************************************************************************
 * Prototype    : Status saveRawByEventCount(DeviceHandle handle,
 *                                           const char* saveDirectory,
 *                                           std::uint64_t events);
 * Description  : Saves raw device data until the streamed event count reaches
 *                the specified count. Blocks until saving completes.
 * Parameters   : [handle]        Device handle returned by openDevice().
 *                [saveDirectory] Directory where raw data will be saved.
 *                [events]        Target event count.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status saveRawByEventCount(DeviceHandle handle,
                                       const char* saveDirectory,
                                       std::uint64_t events);

/*****************************************************************************
 * Prototype    : Status saveRawByFrameCount(DeviceHandle handle,
 *                                           const char* saveDirectory,
 *                                           std::uint64_t frames);
 * Description  : Saves raw device data until the streamed frame count reaches
 *                the specified count. Blocks until saving completes.
 * Parameters   : [handle]        Device handle returned by openDevice().
 *                [saveDirectory] Directory where raw data will be saved.
 *                [frames]        Target frame count.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status saveRawByFrameCount(DeviceHandle handle,
                                       const char* saveDirectory,
                                       std::uint64_t frames);

// ============================================================================
// Frame Image Saving API
//
// Frame images can be generated by one of three frame generation modes:
// 1. Time based: one image is generated every framePeriodMs.
// 2. Event count based: one image is generated every eventsPerFrame events.
// 3. Frame-end based: one image is generated every frameEndCount frame-end packets.
//
// Frame saving can be controlled manually, stopped after a fixed duration, or
// stopped after a fixed number of image frames has been written.
//
// Saved file format: BMP, one file per frame.
// startStream() or startPlayback() must be called before frame saving functions.
// ============================================================================

/*****************************************************************************
 * Prototype    : Status startFrameSaving(InputSource* handle,
 *                                        const char* saveDirectory,
 *                                        FrameGeneration generation);
 * Description  : Starts saving generated frame image data to the specified
 *                directory using the selected frame generation mode.
 *                The generation parameter overrides any previous setFrameGeneration()
 *                setting for the duration of saving. The overridden setting is
 *                also applied to getColorFrame()/getClassicEvents()/getPolarityFrame()/
 *                getTimestampFrame()
 *                while saving is active.
 * Parameters   : [handle]        Input source handle returned by openDevice() or openFile().
 *                [saveDirectory] Directory where frame images will be saved.
 *                [generation]    Frame generation mode and parameter.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status startFrameSaving(InputSource* handle,
                                    const char* saveDirectory,
                                    FrameGeneration generation);

/*****************************************************************************
 * Prototype    : Status stopFrameSaving(InputSource* handle);
 * Description  : Stops frame image saving for the opened input source.
 * Parameters   : [handle] Input source handle returned by openDevice() or openFile().
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status stopFrameSaving(InputSource* handle);

/*****************************************************************************
 * Prototype    : Status saveFrameByTime(InputSource* handle,
 *                                        const char* saveDirectory,
 *                                        std::int32_t durationMs,
 *                                        FrameGeneration generation);
 * Description  : Saves generated frame image data for the specified duration
 *                using the selected frame generation mode. This function blocks
 *                until saving completes.
 * Parameters   : [handle]        Input source handle returned by openDevice() or openFile().
 *                [saveDirectory] Directory where frame images will be saved.
 *                [durationMs]    Saving duration in milliseconds.
 *                [generation]    Frame generation mode and parameter.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status saveFrameByTime(InputSource* handle,
                                    const char* saveDirectory,
                                    std::int32_t durationMs,
                                    FrameGeneration generation);

/*****************************************************************************
 * Prototype    : Status saveFrameByFrameCount(InputSource* handle,
 *                                             const char* saveDirectory,
 *                                             std::uint64_t frameCount,
 *                                             FrameGeneration generation);
 * Description  : Saves generated frame image data until the number of saved
 *                image frames reaches the specified frame count using the
 *                selected frame generation mode. This function blocks until
 *                saving completes.
 * Parameters   : [handle]        Input source handle returned by openDevice() or openFile().
 *                [saveDirectory] Directory where frame images will be saved.
 *                [frameCount]    Number of image frames to save.
 *                [generation]    Frame generation mode and parameter.
 * Return Value : Status::Success on success, or an error status on failure.
 *****************************************************************************/
DELTA_SDK Status saveFrameByFrameCount(InputSource* handle,
                                         const char* saveDirectory,
                                         std::uint64_t frameCount,
                                         FrameGeneration generation);

} // namespace delta

#endif
