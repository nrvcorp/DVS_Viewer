#ifndef DELTA_RECTIFY_HPP
#define DELTA_RECTIFY_HPP

#include <cstddef>
#include <cstdint>

#include "DELTA_Status.hpp"
#include "DELTA_Types.hpp"

namespace delta {

enum class RectificationState : std::int32_t {
    Unconfigured = 0,
    Ready = 1,
    Enabled = 2
};

enum class RectificationTopology : std::int32_t {
    Mono = 0,
    IntegratedStereo = 1,
    DualMonoStereo = 2
};

struct RectificationInfo {
    RectificationState state;
    RectificationTopology topology;
    std::int32_t primaryDeviceIndex;
    std::int32_t secondaryDeviceIndex;
    std::int32_t outputWidth;
    std::int32_t outputHeight;
};

/**
 * Validate and prepare a calibration YAML while every stream, playback, and
 * save operation is stopped. The caller must provide the detected live-device
 * topology so a mono YAML cannot be applied to stereo hardware, or vice versa.
 */
DELTA_SDK Status setupRectification(const char* yamlPath,
                                    std::int32_t primaryDeviceIndex,
                                    std::int32_t secondaryDeviceIndex,
                                    RectificationTopology deviceTopology);

/** Enable rectification for the next live stream start. */
DELTA_SDK Status startRectification();

/** Disable rectification. All live streams must already be stopped. */
DELTA_SDK Status stopRectification();

DELTA_SDK Status getRectificationInfo(RectificationInfo* info);

/** Copy the latest setup or streaming error into a caller-owned buffer. */
DELTA_SDK Status getRectificationLastError(char* text,
                                           std::size_t textCapacity);

} // namespace delta

#endif
