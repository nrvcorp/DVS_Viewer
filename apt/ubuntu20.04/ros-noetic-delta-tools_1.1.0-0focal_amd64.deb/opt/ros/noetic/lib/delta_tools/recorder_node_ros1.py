#!/usr/bin/env python3
"""Starts and stops `rosbag record` on request.

The recording itself is left to `rosbag record`, which already handles
chunking, buffering and clean file termination. This node only owns the child
process and exposes it as two services.
"""

import datetime
import os
import signal
import subprocess

import rospy
from std_srvs.srv import Trigger, TriggerResponse


class Recorder(object):
    def __init__(self):
        self.output_dir = os.path.expanduser(
            rospy.get_param("~output_dir", "~/delta_recordings"))
        self.topics = rospy.get_param("~topics", ["/delta_driver/events"])
        self.base_name = rospy.get_param("~base_name", "delta")
        self.split_size_mb = int(rospy.get_param("~split_size_mb", 0))

        if isinstance(self.topics, str):
            self.topics = [self.topics]

        self.proc = None
        self.path = None
        self.started_at = None

        if not os.path.isdir(self.output_dir):
            os.makedirs(self.output_dir)

        rospy.Service("~start", Trigger, self.on_start)
        rospy.Service("~stop", Trigger, self.on_stop)
        rospy.on_shutdown(self.shutdown)

        rospy.loginfo("recorder: ready, writing to %s", self.output_dir)
        rospy.loginfo("recorder: topics %s", ", ".join(self.topics))

    def is_recording(self):
        return self.proc is not None and self.proc.poll() is None

    def on_start(self, _req):
        if self.is_recording():
            return TriggerResponse(success=False,
                                   message="already recording %s" % self.path)

        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        self.path = os.path.join(self.output_dir, "%s_%s" % (self.base_name, stamp))

        cmd = ["rosbag", "record", "-O", self.path]
        if self.split_size_mb > 0:
            cmd += ["--split", "--size=%d" % self.split_size_mb]
        cmd += self.topics

        try:
            self.proc = subprocess.Popen(cmd)
        except OSError as e:
            return TriggerResponse(success=False, message="cannot run rosbag: %s" % e)

        self.started_at = rospy.Time.now()
        rospy.loginfo("recorder: started %s.bag", self.path)
        return TriggerResponse(success=True, message="%s.bag" % self.path)

    def on_stop(self, _req):
        if not self.is_recording():
            return TriggerResponse(success=False, message="not recording")

        # SIGINT closes the bag cleanly; killing outright leaves a .bag.active.
        self.proc.send_signal(signal.SIGINT)
        self.proc.wait()
        self.proc = None

        elapsed = (rospy.Time.now() - self.started_at).to_sec()
        bag = self.path + ".bag"
        size_mb = os.path.getsize(bag) / (1024.0 * 1024.0) if os.path.exists(bag) else 0.0

        rospy.loginfo("recorder: stopped after %.1f s, %.1f MB", elapsed, size_mb)
        if size_mb > 0.0 and elapsed > 0.0:
            rospy.loginfo("recorder: %.1f MB/s written", size_mb / elapsed)

        return TriggerResponse(
            success=True,
            message="%s (%.1f s, %.1f MB)" % (bag, elapsed, size_mb))

    def shutdown(self):
        if self.is_recording():
            rospy.loginfo("recorder: stopping recording before shutdown")
            self.proc.send_signal(signal.SIGINT)
            self.proc.wait()


if __name__ == "__main__":
    rospy.init_node("delta_recorder")
    Recorder()
    rospy.spin()
