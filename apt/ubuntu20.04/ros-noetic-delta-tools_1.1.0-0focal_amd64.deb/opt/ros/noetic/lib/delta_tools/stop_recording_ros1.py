#!/usr/bin/env python3
"""Tells the recorder node to close the bag it is writing."""

import sys

import rospy
from std_srvs.srv import Trigger


def main():
    rospy.init_node("stop_recording", anonymous=True)
    service = rospy.get_param("~service", "/delta_recorder/stop")

    try:
        rospy.wait_for_service(service, timeout=5.0)
    except rospy.ROSException:
        print("recorder node is not running (no service %s)" % service)
        return 1

    response = rospy.ServiceProxy(service, Trigger)()
    print(("saved: " if response.success else "failed: ") + response.message)
    return 0 if response.success else 1


if __name__ == "__main__":
    sys.exit(main())
