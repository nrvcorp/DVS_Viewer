#pragma once

#include <cstdint>
#include <string>
#include <vector>

#include <event_camera_codecs/decoder_factory.h>
#include <event_camera_codecs/event_processor.h>

#include "delta_tools/ros_compat.hpp"

namespace delta_tools {

// Tallies coordinate ranges, polarity balance and time direction, which is
// what reveals a mis-parsed bitfield.
class EventAccumulator : public event_camera_codecs::EventProcessor
{
public:
  void eventCD(uint64_t sensorTime, uint16_t ex, uint16_t ey, uint8_t polarity) override;
  bool eventExtTrigger(uint64_t, uint8_t, uint8_t) override { return true; }
  void finished() override {}
  void rawData(const char *, size_t) override {}

  void resize(uint16_t width, uint16_t height);
  void clearImage();
  void resetStats();

  uint64_t events = 0;
  uint64_t onEvents = 0;
  uint64_t outOfRange = 0;
  uint64_t timeReversals = 0;
  uint16_t xMin = 0xFFFF;
  uint16_t xMax = 0;
  uint16_t yMin = 0xFFFF;
  uint16_t yMax = 0;
  uint64_t firstTime = 0;
  uint64_t lastTime = 0;

  uint16_t width = 0;
  uint16_t height = 0;
  std::vector<uint8_t> image;

private:
  bool haveTime_ = false;
};

class Renderer
{
public:
  explicit Renderer(NodeHandle & node);

  Renderer(const Renderer &) = delete;
  Renderer & operator=(const Renderer &) = delete;

  bool initialize();

private:
  void onEventPacket(const EventPacketMsg & msg);
  void publishImage(const EventPacketMsg & msg);
  void printStatistics();

  NodeHandle & node_;

#ifdef USING_ROS_1
  ros::Subscriber subscriber_;
  ros::Publisher imagePublisher_;
#else
  rclcpp::Subscription<EventPacketMsg>::SharedPtr subscriber_;
  rclcpp::Publisher<ImageMsg>::SharedPtr imagePublisher_;
#endif

  event_camera_codecs::DecoderFactory<EventPacketMsg, EventAccumulator> factory_;
  EventAccumulator accumulator_;

  std::string topicName_;
  double statisticsInterval_ = 2.0;
  uint64_t framePeriodNs_ = 33ULL * 1000ULL * 1000ULL;
  uint64_t lastStatsNs_ = 0;
  uint64_t lastImageNs_ = 0;
  uint64_t packets_ = 0;
  bool warnedNoDecoder_ = false;
};

}  // namespace delta_tools
