import os

from datetime import datetime

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess
from launch.substitutions import LaunchConfiguration, PythonExpression


def generate_launch_description():
    qos_overrides = os.path.join(
        get_package_share_directory('delta_tools'), 'config', 'record_qos.yaml')
    # Resolved at load time so every run gets its own bag directory.
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')

    return LaunchDescription([
        DeclareLaunchArgument(
            'output_dir', default_value=os.path.join(os.path.expanduser('~'), 'delta_recordings')),
        DeclareLaunchArgument('base_name', default_value='delta'),
        DeclareLaunchArgument('topic', default_value='/delta_driver/events'),
        DeclareLaunchArgument('split_size_mb', default_value='0'),

        ExecuteProcess(
            cmd=[
                'ros2', 'bag', 'record',
                '--qos-profile-overrides-path', qos_overrides,
                '--max-bag-size',
                PythonExpression([LaunchConfiguration('split_size_mb'), ' * 1024 * 1024']),
                '-o', [LaunchConfiguration('output_dir'), '/',
                       LaunchConfiguration('base_name'), '_', stamp],
                LaunchConfiguration('topic'),
            ],
            output='screen',
        ),
    ])
