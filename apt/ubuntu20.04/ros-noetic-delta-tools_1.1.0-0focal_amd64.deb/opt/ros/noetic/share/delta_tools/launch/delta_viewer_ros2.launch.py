import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    driver_launch = os.path.join(
        get_package_share_directory('delta_driver'), 'launch', 'delta_driver.launch.py')

    return LaunchDescription([
        DeclareLaunchArgument('sensor_setting_path', default_value=''),
        DeclareLaunchArgument('device_index', default_value='0'),
        DeclareLaunchArgument('topic', default_value='/delta_driver/events'),
        DeclareLaunchArgument('image_fps', default_value='30'),
        DeclareLaunchArgument('statistics_interval', default_value='2.0'),
        DeclareLaunchArgument('subscriber_queue_size', default_value='1'),
        DeclareLaunchArgument('rqt', default_value='false'),

        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(driver_launch),
            launch_arguments={
                'sensor_setting_path': LaunchConfiguration('sensor_setting_path'),
                'device_index': LaunchConfiguration('device_index'),
            }.items(),
        ),

        Node(
            package='delta_tools',
            executable='delta_renderer_node',
            name='delta_renderer',
            output='screen',
            parameters=[{
                'topic': ParameterValue(
                    LaunchConfiguration('topic'), value_type=str),
                'image_fps': ParameterValue(
                    LaunchConfiguration('image_fps'), value_type=int),
                'statistics_interval': ParameterValue(
                    LaunchConfiguration('statistics_interval'), value_type=float),
                'subscriber_queue_size': ParameterValue(
                    LaunchConfiguration('subscriber_queue_size'), value_type=int),
            }],
        ),

        Node(
            condition=IfCondition(LaunchConfiguration('rqt')),
            package='rqt_image_view',
            executable='rqt_image_view',
            name='delta_image_view',
            arguments=['/delta_renderer/image'],
        ),
    ])
