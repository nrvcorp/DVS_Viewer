# delta_tools

Renders and records what [delta_driver](../delta_driver/README.md) publishes.

The nodes here never touch the camera. They consume
`event_camera_msgs/EventPacket`, so they work the same on a live stream and on
a recording.

## Renderer

Decodes packets and publishes an image.

```bash
roslaunch delta_tools delta_viewer_ros1.launch rqt:=true sensor_setting_path:=$(rospack find delta_driver)/config/sensor/Delta_01_1000FPS.txt
```

This launch starts the driver as well, which is why it needs the sensor setting
file. `rqt:=true` also opens an image window; leave it off if you only want the
topic.

To render something already running, or a bag being played back, start the node
on its own:

```bash
rosrun delta_tools delta_renderer_node _topic:=/delta_driver/events
```

| Topic | Direction | Type |
| --- | --- | --- |
| `topic` parameter | in | `event_camera_msgs/EventPacket` |
| `~image` | out | `sensor_msgs/Image`, `mono8` |

| Parameter | Default | Meaning |
| --- | --- | --- |
| `topic` | `/delta_driver/events` | Packets to render. |
| `image_fps` | `30` | Images published per second. |
| `subscriber_queue_size` | `1` | See below. |
| `statistics_interval` | `2.0` | Seconds between rate printouts. |

### In one process with the driver

Both are also nodelets, so they can run in a single manager and pass packets as
a pointer rather than serialising them:

```bash
roslaunch delta_tools delta_viewer_nodelet_ros1.launch rqt:=true sensor_setting_path:=$(rospack find delta_driver)/config/sensor/Delta_01_1000FPS.txt
```

Same parameters, same result on screen, without the cost of moving the data
between two processes.

### It drops rather than lags

The queue size is 1 on purpose. An event camera can produce packets faster than
a renderer can draw them, and a deeper queue would only mean drawing older and
older frames while the delay grows without bound.

With a queue of 1 the view stays current and packets are dropped instead.
**Recording is unaffected** — a recorder subscribes separately with its own
queue. Raise it only if you would rather see every packet late than the newest
one now.

## Recorder

`rosbag record` covers most uses. This node is for when recording has to start
and stop under program control, without restarting anything.

```bash
roslaunch delta_tools delta_recorder_ros1.launch
rosservice call /delta_recorder/start
rosservice call /delta_recorder/stop
```

Each start writes a new bag; stop closes it. The same two calls are also
available as `start_recording_ros1.py` and `stop_recording_ros1.py`.

| Parameter | Default | Meaning |
| --- | --- | --- |
| `output_dir` | `~/delta_recordings` | Where bags are written. |
| `topics` | `[/delta_driver/events]` | What to record. |
| `base_name` | `delta` | File name prefix. |
| `split_size_mb` | `0` | Split into files of this size. `0` does not split. |

## Playback

```bash
rosbag play <file>.bag
rosrun delta_tools delta_renderer_node _topic:=/delta_driver/events
```

Packets are stored encoded, so playback needs the same `event_camera_codecs`
that live rendering does; see the [delta_driver
README](../delta_driver/README.md) if the renderer reports no decoder.

## License

Proprietary. Contact <sales@nrv.kr>.
