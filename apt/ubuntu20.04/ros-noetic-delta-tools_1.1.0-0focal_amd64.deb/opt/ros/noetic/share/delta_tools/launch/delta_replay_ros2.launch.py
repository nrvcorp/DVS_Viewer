from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess
from launch.conditions import IfCondition, UnlessCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    # --clock is needed or the renderer emits nothing, and its rate must be
    # spelled out or the optional value swallows the next argument.
    play = ['ros2', 'bag', 'play', LaunchConfiguration('bag'), '--clock', '100']

    return LaunchDescription([
        DeclareLaunchArgument('bag'),
        DeclareLaunchArgument('topic', default_value='/delta_driver/events'),
        DeclareLaunchArgument('image_fps', default_value='30'),
        DeclareLaunchArgument('statistics_interval', default_value='2.0'),
        DeclareLaunchArgument('subscriber_queue_size', default_value='1'),
        DeclareLaunchArgument('loop', default_value='false'),
        DeclareLaunchArgument('rqt', default_value='false'),

        Node(
            package='delta_tools',
            executable='delta_renderer_node',
            name='delta_renderer',
            output='screen',
            parameters=[{
                'use_sim_time': True,
                'topic': ParameterValue(
                    LaunchConfiguration('topic'), value_type=str),
                'image_fps': ParameterValue(
                    LaunchConfiguration('image_fps'), value_type=int),
                'statistics_interval': ParameterValue(
                    LaunchConfiguration('statistics_interval'), value_type=float),
                'subscriber_queue_size': ParameterValue(
                    LaunchConfiguration('subscriber_queue_size'), value_type=int),
            }],
        ),

        Node(
            condition=IfCondition(LaunchConfiguration('rqt')),
            package='rqt_image_view',
            executable='rqt_image_view',
            name='delta_image_view',
            arguments=['/delta_renderer/image'],
            parameters=[{'use_sim_time': True}],
        ),

        ExecuteProcess(
            condition=UnlessCondition(LaunchConfiguration('loop')),
            cmd=play, output='screen'),
        ExecuteProcess(
            condition=IfCondition(LaunchConfiguration('loop')),
            cmd=play + ['--loop'], output='screen'),
    ])
