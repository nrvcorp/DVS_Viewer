
"use strict";

let EventPacket = require('./EventPacket.js');

module.exports = {
  EventPacket: EventPacket,
};
