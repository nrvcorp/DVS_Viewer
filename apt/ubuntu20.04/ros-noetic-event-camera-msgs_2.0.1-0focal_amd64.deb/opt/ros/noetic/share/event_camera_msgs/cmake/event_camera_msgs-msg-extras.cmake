set(event_camera_msgs_MESSAGE_FILES "msg_ros1/EventPacket.msg")
set(event_camera_msgs_SERVICE_FILES "")
