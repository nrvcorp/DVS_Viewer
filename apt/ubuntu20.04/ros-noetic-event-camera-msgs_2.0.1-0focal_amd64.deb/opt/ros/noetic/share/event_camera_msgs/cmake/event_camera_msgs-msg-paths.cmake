# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${event_camera_msgs_DIR}/.." "msg_ros1" event_camera_msgs_MSG_INCLUDE_DIRS UNIQUE)
set(event_camera_msgs_MSG_DEPENDENCIES std_msgs)
