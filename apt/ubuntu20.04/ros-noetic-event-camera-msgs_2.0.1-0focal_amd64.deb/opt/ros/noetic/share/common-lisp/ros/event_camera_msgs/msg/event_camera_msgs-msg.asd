
(cl:in-package :asdf)

(defsystem "event_camera_msgs-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :std_msgs-msg
)
  :components ((:file "_package")
    (:file "EventPacket" :depends-on ("_package_EventPacket"))
    (:file "_package_EventPacket" :depends-on ("_package"))
  ))