(cl:defpackage event_camera_msgs-msg
  (:use )
  (:export
   "<EVENTPACKET>"
   "EVENTPACKET"
  ))

