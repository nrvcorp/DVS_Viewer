(cl:in-package event_camera_msgs-msg)
(cl:export '(HEADER-VAL
          HEADER
          HEIGHT-VAL
          HEIGHT
          WIDTH-VAL
          WIDTH
          SEQ-VAL
          SEQ
          TIME_BASE-VAL
          TIME_BASE
          ENCODING-VAL
          ENCODING
          IS_BIGENDIAN-VAL
          IS_BIGENDIAN
          EVENTS-VAL
          EVENTS
))